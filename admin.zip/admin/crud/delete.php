<?php
require_once "../../db/db.php";

$delete = "";

if(!empty($_POST['tag_id']))
{
    $tag_id = $_POST['tag_id'];
     $delete = "DELETE FROM `tags` WHERE `tag_id`=$tag_id";  
}
else if(!empty($_POST['id']))
{
   $id = $_POST['id'];

 $delete = "DELETE FROM `crud` WHERE `id`=$id";
}

$delete = $con->query($delete);

if($delete)
{
    echo "<script>alert('Record Deleted...!');</script>";
    $res = [
        'status' => 200,
        'message' => 'Record Deleted Successfully...!'
    ];
}
else
{
    $res = [
        'status' => 500,
        'message' => 'Error While Deleting...!'
    ];
}

?>
