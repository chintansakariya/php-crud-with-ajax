<?php
require_once "../../db/db.php";

// Get parameters sent by DataTables
$start = $_GET['start'];
$length = $_GET['length'];
$searchValue = $_GET['search']['value'];
$orderByColumn = $_GET['order'][0]['column'];
$orderByDir = $_GET['order'][0]['dir'];

$columns = array(
    0 => 'id',
    1 => 'heading',
    2 => 'sub_heading',
    3 => 'description',
    4 => 'tag_name',
    5 => 'image'
   
);

// Construct the base SQL query
$query = "SELECT count(*) as total
FROM crud as c
LEFT JOIN tags as t ON c.tag_id = t.tag_id
WHERE c.id LIKE '%$searchValue%'
   OR c.heading LIKE '%$searchValue%'
   OR c.sub_heading LIKE '%$searchValue%'
   OR c.description LIKE '%$searchValue%'
   OR t.name LIKE '%$searchValue%';";

$result = $con->query($query);
$row = $result->fetch_assoc();
$totalRecords = $row['total'];

$query = "SELECT c.*, t.name as tag_name
FROM crud as c
LEFT JOIN tags as t ON c.tag_id = t.tag_id
WHERE c.id LIKE '%$searchValue%'
   OR c.heading LIKE '%$searchValue%'
   OR c.sub_heading LIKE '%$searchValue%'
   OR c.description LIKE '%$searchValue%'
   OR t.name LIKE '%$searchValue%'
";

// Add sorting to the query
if (isset($columns[$orderByColumn])) {
    $query .= " ORDER BY " . $columns[$orderByColumn] . " " . $orderByDir;
}

// Add paging to the query
$query .= " LIMIT $start, $length";

$result = $con->query($query);

$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$response = array(
    "draw" => intval($_GET['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $totalRecords,
    "data" => $data
);
echo json_encode($response);
?>
