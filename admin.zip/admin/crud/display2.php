<?php
require_once "../../db/db.php";

// Get parameters sent by DataTables
$start = $_GET['start'];
$length = $_GET['length'];
$searchValue = $_GET['search']['value'];
$orderByColumn = $_GET['order'][0]['column'];
$orderByDir = $_GET['order'][0]['dir'];

$columns = array(
    0 => 'tag_id',
    1 => 'name',
    2 => 'created_at',
    3 => 'deleted_at'
);

// Construct the base SQL query
$query = "SELECT COUNT(*) AS total FROM `tags` WHERE tag_id LIKE '%$searchValue%' OR name LIKE '%$searchValue%'";

$result = $con->query($query);
$row = $result->fetch_assoc();
$totalRecords = $row['total'];

$query = "SELECT * FROM `tags` WHERE tag_id LIKE '%$searchValue%' OR name LIKE '%$searchValue%'";

// Add sorting to the query
if (isset($columns[$orderByColumn])) {
    $query .= " ORDER BY " . $columns[$orderByColumn] . " " . $orderByDir;
}

// Add paging to the query
$query .= " LIMIT $start, $length";

$result = $con->query($query);

$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$response = array(
    "draw" => intval($_GET['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $totalRecords,
    "data" => $data
);

echo json_encode($response);
?>
