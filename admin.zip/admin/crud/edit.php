<?php

require_once "../../db/db.php";

if(!empty($_POST['tag_id']))
{
    $tag_id = $_POST['tag_id'];

    $edit = "SELECT * FROM `tags` WHERE `tag_id` = $tag_id";
}
else if(!empty($_POST['id']))
{
    $id = $_POST['id'];


    //editing right now
   // $edit = "SELECT * FROM `crud` WHERE `id` = $id";
    $edit = "SELECT * FROM `crud` as c LEFT JOIN tags as t ON c.tag_id=t.tag_id where c.id = '$id'";
}


$edit = $con->query($edit);

$res = $edit->fetch_assoc();

echo json_encode($res);
