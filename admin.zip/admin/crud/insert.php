<?php
require_once "../../db/db.php"; 


    $heading = $con->real_escape_string($_POST['heading']);
    $sheading = $con->real_escape_string($_POST['sheading']);
    $description = $con->real_escape_string($_POST['description']);
    $tag_id = $_POST['tag'];
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $ext = pathinfo($image,PATHINFO_EXTENSION);
    $rndmno= rand(0,1000000);
    $image1 = 'upload'.$rndmno.'.'.$ext;
    // global $res;
    
    if($heading ==  NULL || $sheading ==  NULL || $description == NULL)
    {
        $res = [
            'status' => 422,
            'message' => 'All Fields Are Required...!'
        ];
         echo json_encode($res);
         return false;
        
    }
    else
    {
        $imgUpload =move_uploaded_file($image_tmp,"../upload/".$image1);

        $insert = "";
        $update = ""; 
        if(isset($_POST['update']))
        {
            $id = $_POST['id'];
         if($imgUpload)
         {
            $update = "UPDATE `crud` SET `heading`='$heading',`sub_heading`='$sheading',`description`='$description',`image`='$image1',`tag_id`='$tag_id' WHERE `id` = $id";

         }
         else
         {
            $update = "UPDATE `crud` SET `heading`='$heading',`sub_heading`='$sheading',`description`='$description',`tag_id`='$tag_id' WHERE `id` = $id";

         }

          $update = $con->query($update);

        }
        else
        {
            if($imgUpload)
            {
                $insert = "INSERT INTO `crud`(`heading`, `sub_heading`, `description`,`image`,`tag_id`) VALUES ('$heading','$sheading','$description','$image1',$tag_id)";
            }
            else
            {
                $res = [
                    'status' => 500,
                    'message' => 'Please Upload Image...!'
                ];
                echo json_encode($res);
                return false;
            }

            $insert = $con->query($insert);
        }

    if($insert)
    {
       $res = [
            'status' => 200,
            'message' => 'Inserted Successfully...!'
        ];
        echo json_encode($res);
        return false;
        
    }
    else if($update)
    {
       $res = [
            'status' => 200,
            'message' => 'Updated Successfully...!'
        ];
        echo json_encode($res);
        return false;
        
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Error...!'
        ];
        echo json_encode($res);
        return false;
       
    }

}

?>