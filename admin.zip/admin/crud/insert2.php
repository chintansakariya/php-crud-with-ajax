<?php
require_once "../../db/db.php"; 

    $tag_name = $con->real_escape_string($_POST['tag_name']);

    if($tag_name ==  NULL)
    {
        $res = [
            'status' => 422,
            'message' => 'Please Insert Tag Name...!'
        ];
         echo json_encode($res);
         return false;
    }
    else
    {

        $insert = "";
        $update = ""; 
        if(isset($_POST['update']))
        {
            $tag_id = $_POST['tag_id'];
        
            $update = "UPDATE `tags` SET `name`='$tag_name' WHERE `tag_id` = $tag_id";

             $update = $con->query($update);
        }
        else{

            $insert = "INSERT INTO `tags`(`name`) VALUES ('$tag_name')";
            
            $insert = $con->query($insert);
        }

}
if($insert)
{
   $res = [
        'status' => 200,
        'message' => 'Inserted Successfully...!'
    ];
    echo json_encode($res);
    return false;
    
}
else if($update)
{
   $res = [
        'status' => 200,
        'message' => 'Updated Successfully...!'
    ];
    echo json_encode($res);
    return false;
    
}
else
{
    $res = [
        'status' => 500,
        'message' => 'Error...!'
    ];
    echo json_encode($res);
    return false;
   
}

?>