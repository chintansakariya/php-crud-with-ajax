<?php require_once "inc/header.php"; ?>

<?php
session_start();
if($_SESSION['name'] == "")
{
  header("Location: login.php");
  exit();
}
?>
<body class="hold-transition sidebar-mini layout-fixed">

<?php require_once "inc/main_nav.php"; ?>
<?php require_once "inc/left_nav.php"; ?>


<!-- data-table -->
<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DataTables</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">


              <!-- Pop up form with modal -->
              <button type="button" class="btn btn-info btn-lg py-3 px-5" data-toggle="modal" data-target="#myModal" onclick="textMain()">Add</button>

              <div class="modal justify-content-center text-center" id="myModal" role="dialog">
  <div class="modal-dialog">
  
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal" id="close">&times;</button>

      </div>
      <div class="modal-body">
        <div class="alert alert-warning d-none" id="errorMessage"></div>
      <div class="card">
    <div class="card-body login-card-body">
      <form method="post" class="form1" enctype="multipart/form-data" id="form1">
        <div class="input-group mb-3">
        <input type="hidden" class="form-control"  name="id" id="id">

          <input type="text" class="form-control border-right-1" placeholder="heading" name="heading" id="heading">
          
        </div>
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="sub-heading" name="sheading" id="sheading">
          
        </div>
        <div class="input-group mb-3">
            <textarea name="description" id="description" cols="10" rows="3" class="form-control" placeholder="Description"></textarea>
          
        </div>
        <div class="input-group mb-3">
        
            <input type="file" name="image" id="image" class="form-control">
          
        </div>
        <div class="input-group mb-3">
       <select name="tag" id="tag">
        <option value="">Select Tag</option>
       <?php
                            $fetch = "SELECT `tag_id`,`name` FROM `tags`";
                            $fetch = $con->query($fetch);
                            while($row = $fetch->fetch_assoc())
                            {  
                            echo "<option value='".$row['tag_id']."'>".$row['name']. "</option>";
                            }
                            ?>
       </select>
</div>    
<div class="row w-100">
          
          <!-- /.col -->
            <button type="submit" class="btn btn-primary btn-block w-100" name="insert" id="insert" onclick="alertBox()"><span id="insert-update"></span></button>
        </div>      
        </div>
        
      </form>
    </div>
      </div>
      </div>
    </div>
  </div>
</div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4"><div class="row"><div class="col-sm-12 col-md-6"></div><div class="col-sm-12 col-md-6"></div></div><div class="row"><div class="col-sm-12">
                  <table id="example2" class="table table-bordered table-hover dataTable dtr-inline w-100" aria-describedby="example2_info">
                  <thead>
                  <tr>
                  <th class="sorting sorting_desc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" aria-sort="descending">Id</th>
                    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Heading</th>
                    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Sub-Heading</th>
                    <th class="sorting description" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Description</th>
                    <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Tag Name</th>
                    <th class="sorting image1" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Image</th>
                    <th class="sorting edit" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Edit</th>
                </tr>
                  </thead>
                  <tbody id="response">   
               
                </tbody>
                  
                </table></div></div></div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <?php require_once "inc/footer.php"; ?>