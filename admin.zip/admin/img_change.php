<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="image" id="">
        <button type="submit">submit</button>
    </form>
</body>
</html>
<?php
$image = $_FILES['image']['name'];

$image = pathinfo($image,PATHINFO_EXTENSION);
echo $image;
?>