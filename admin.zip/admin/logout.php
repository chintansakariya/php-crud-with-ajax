<?php
session_start();

if(isset($_SESSION['name']))
{
    unset($_SESSION['name']);
    session_destroy();
    header("Location:login.php");
    exit();
//    echo "Session Unset";
}
else
{
    echo "<script>alert('To Access This Page Login First...!');</script>";
    echo "<script>window.location.href = 'login.php';</script>";
}
?>
