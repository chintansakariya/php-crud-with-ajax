<?php require_once "inc/header.php"; 

$id = 122;

$edit = "SELECT * FROM `crud` WHERE `id` = $id";

$edit = $con->query($edit);

$edit = $edit->fetch_assoc();

print_r($edit);
while($edit)
{
?>
<div class="modal justify-content-center text-center d-block" id="myModal" role="dialog">
  <div class="modal-dialog">
  
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Insert Data</h4>
        <button type="button" class="close" data-dismiss="modal" id="close">&times;</button>

      </div>
      <div class="modal-body">
        <div class="alert alert-warning d-none" id="errorMessage"></div>
      <div class="card">
    <div class="card-body login-card-body">
      <form method="post" class="form1" enctype="multipart/form-data" id="form1">
        <div class="input-group mb-3">
          <input type="text" class="form-control border-right-1" placeholder="heading" name="heading" id="heading" value="<?php echo $edit['heading'];?>">
          
        </div>
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="sub-heading" name="sheading" id="sheading">
          
        </div>
        <div class="input-group mb-3">
            <textarea name="description" id="description" cols="10" rows="3" class="form-control" placeholder="Description"></textarea>
          
        </div>
        <div class="input-group mb-3">
            <input type="file" name="image" id="image" class="form-control">
          
        </div>
        <div class="row m-0">
          
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block" name="insert" id="insert" onclick="alertBox()">Insert</button>
          </div>
        </div>
      </form>
    </div>
      </div>
      </div>
    </div>
  </div>
</div>

<?php require_once "inc/footer.php"; 

}
?>
